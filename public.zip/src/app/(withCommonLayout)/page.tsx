import Slider from "@/components/UI/Slider/Slider";

export default function Home() {
  return (
    <>
      <Slider />
    </>
  );
}
